# 💰 Expense Tracker App

## 🚀 Description
A powerful and user-friendly Expense Tracker App with **dual-mode functionality**:
- **Expense Mode:** Track and split expenses among multiple members.
- **Monthly Overview Mode:** Manage monthly income, savings, and expenses with PDF report generation.

## 🛠️ Tech Stack
- HTML, CSS, JavaScript
- PDF generation using `jspdf`
- Local storage for data persistence

## 🔥 Features
- Split expenses equally among multiple users.
- Save and delete monthly overview data.
- Generate PDF reports for monthly expenses.
- Responsive and visually appealing UI.

## 📷 Screenshots
(Add screenshots of your app here)

## 💡 How to Run
1. Clone the repository:  

https://github.com/DEEPAK21072005/Expense-Tracker-App-.git
2. Open `index.html` in your browser.  
3. Enjoy tracking your expenses!

## 🔥 Contribute
Feel free to contribute by raising issues or making a pull request.

## 📄 License
This project is licensed under the MIT License - see the `LICENSE` file for details.
